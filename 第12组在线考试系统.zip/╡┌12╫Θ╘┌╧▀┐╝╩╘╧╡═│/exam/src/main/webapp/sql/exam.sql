/*
 Navicat Premium Data Transfer

 Source Server         : Mysql
 Source Server Type    : MySQL
 Source Server Version : 50562
 Source Host           : localhost:3306
 Source Schema         : exam

 Target Server Type    : MySQL
 Target Server Version : 50562
 File Encoding         : 65001

 Date: 14/06/2020 04:29:49
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for adminuser
-- ----------------------------
DROP TABLE IF EXISTS `adminuser`;
CREATE TABLE `adminuser`  (
  `uid` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of adminuser
-- ----------------------------
INSERT INTO `adminuser` VALUES (300123, '张知', 'admin123');

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`  (
  `cid` int(11) NOT NULL,
  `cname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tid` int(11) NOT NULL,
  `tname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cid`, `tid`) USING BTREE,
  INDEX `cid`(`cid`) USING BTREE,
  INDEX `cname`(`cname`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES (10, '数据库', 200123, '何哲');
INSERT INTO `course` VALUES (20, '计算机', 200124, '柯叶');
INSERT INTO `course` VALUES (30, '软件工程导论', 200125, '张祐');

-- ----------------------------
-- Table structure for grade
-- ----------------------------
DROP TABLE IF EXISTS `grade`;
CREATE TABLE `grade`  (
  `gid` int(11) NOT NULL,
  `gname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`gid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of grade
-- ----------------------------
INSERT INTO `grade` VALUES (2018, '2018级');
INSERT INTO `grade` VALUES (2019, '2019级');

-- ----------------------------
-- Table structure for paper
-- ----------------------------
DROP TABLE IF EXISTS `paper`;
CREATE TABLE `paper`  (
  `pid` int(11) NOT NULL,
  `cid` int(11) NULL DEFAULT NULL,
  `cname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tid` int(11) NULL DEFAULT NULL,
  `tname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pid`) USING BTREE,
  INDEX `tname`(`tname`) USING BTREE,
  CONSTRAINT `tname` FOREIGN KEY (`tname`) REFERENCES `teacheruser` (`tname`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of paper
-- ----------------------------
INSERT INTO `paper` VALUES (101, 10, '数据库', '单元测试1', 200123, '何哲');
INSERT INTO `paper` VALUES (102, 10, '数据库', '单元测试2', 200123, '何哲');
INSERT INTO `paper` VALUES (103, 10, '数据库', '单元测试3', 200123, '何哲');
INSERT INTO `paper` VALUES (104, 10, '数据库', '单元测试4', 200123, '何哲');
INSERT INTO `paper` VALUES (105, 10, '数据库', '单元测试5', 200123, '何哲');
INSERT INTO `paper` VALUES (201, 20, '计算机', '单元测试1', 200123, '何哲');
INSERT INTO `paper` VALUES (202, 20, '计算机', '单元测试2', 200123, '何哲');
INSERT INTO `paper` VALUES (203, 20, '计算机', '单元测试3', 200123, '何哲');
INSERT INTO `paper` VALUES (301, 30, '软件工程导论', '单元测试1', 200123, '何哲');

-- ----------------------------
-- Table structure for quenstiontype
-- ----------------------------
DROP TABLE IF EXISTS `quenstiontype`;
CREATE TABLE `quenstiontype`  (
  `qtid` int(11) NOT NULL,
  `qtname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `fz` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`qtid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of quenstiontype
-- ----------------------------
INSERT INTO `quenstiontype` VALUES (1, '单选题', '10');
INSERT INTO `quenstiontype` VALUES (2, '判断题', '25');
INSERT INTO `quenstiontype` VALUES (3, '填空题', '10');

-- ----------------------------
-- Table structure for question
-- ----------------------------
DROP TABLE IF EXISTS `question`;
CREATE TABLE `question`  (
  `qutid` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `qcontcnt` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `aoption` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bopion` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `coption` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `doption` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `qanswer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `fz` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tid` int(11) NOT NULL,
  `teacher` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`qutid`, `qid`, `pid`, `tid`) USING BTREE,
  INDEX `teacher`(`teacher`) USING BTREE,
  CONSTRAINT `qutid` FOREIGN KEY (`qutid`) REFERENCES `quenstiontype` (`qtid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `teacher` FOREIGN KEY (`teacher`) REFERENCES `teacheruser` (`tname`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of question
-- ----------------------------
INSERT INTO `question` VALUES (1, 1, '保护数据库，防止未经授权的或不合法的使用造成的数据泄漏、更改破坏。这是指数据的（  ）', '安全性', '完整性', '并发控制', '恢复', 'A.安全性', 101, '10', 200123, '何哲');
INSERT INTO `question` VALUES (1, 2, '下列SQL语句中，能够实现“收回用户ZHAO对学生表（STUD）中学号（XH）的修改权”这一功能的是（  ）。', 'REVOKE UPDATE(XH) ON TABLE FROM ZHAO', 'REVOKE UPDATE(XH) ON TABLE FROM PUBLIC', 'REVOKE UPDATE(XH) ON STUD FROM ZHAO', 'REVOKE UPDATE(XH) ON STUD FROM', 'C.REVOKE UPDATE(XH) ON STUD FROM ZHAO', 101, '10', 200123, '何哲');
INSERT INTO `question` VALUES (1, 3, '安全性控制的防范对象是（  ），防止他们对数据库数据的存取。', '不合语义的数据', '非法用户', '不正确的数据', '不符合约束数据', 'B.非法用户', 101, '10', 200123, '何哲');
INSERT INTO `question` VALUES (1, 4, '（  ）是存储在计算机内有结构的数据的集合。', '数据库系统', '数据库', '数据库管理系统', '数据结构', 'B.数据库', 101, '10', 200123, '何哲');
INSERT INTO `question` VALUES (1, 5, '数据库系统的基本特点不包括（  ）', '数据共享性高、冗余度低', '数据独立性高', '数据结构化', '数据设计面向某个具体的应用', 'D.数据设计面向某个具体的应用', 101, '10', 200123, '何哲');
INSERT INTO `question` VALUES (2, 1, '数据冗余可能导致的问题有浪费存储空间、修改复杂和潜在的数据不一致性。（  )', '正确', '错误', '', '', 'A.正确', 101, '25', 200123, '何哲');
INSERT INTO `question` VALUES (2, 2, '项目管理是指在项目中运用专门的知识、技能、工具和方法，使项目能够实现或超过项目干系人的需要和期望。（ ）', '正确', '错误', '', '', 'A.正确', 101, '25', 200123, '何哲');

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score`  (
  `cid` int(11) NOT NULL,
  `cname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `pname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `grade` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `score` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cid`, `pid`, `sid`) USING BTREE,
  INDEX `cid`(`cid`) USING BTREE,
  INDEX `name`(`name`) USING BTREE,
  INDEX `pid`(`pid`) USING BTREE,
  CONSTRAINT `name` FOREIGN KEY (`name`) REFERENCES `student` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pid` FOREIGN KEY (`pid`) REFERENCES `paper` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of score
-- ----------------------------
INSERT INTO `score` VALUES (10, '数据库', 101, '单元测试1', 2018123, '张一', '2018', '90');
INSERT INTO `score` VALUES (10, '数据库', 101, '单元测试1', 2018124, '王二', '2018', '89');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `sid` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `grade` int(11) NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sid`, `grade`) USING BTREE,
  INDEX `grade`(`grade`) USING BTREE,
  INDEX `sid`(`sid`) USING BTREE,
  INDEX `name`(`name`) USING BTREE,
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`grade`) REFERENCES `grade` (`gid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('2018123', 'zhy123', '张一', 2018, '14256349076');
INSERT INTO `student` VALUES ('2018124', 'wange124', '王二', 2018, '12345678912');
INSERT INTO `student` VALUES ('2018125', 'zhhe125', '周和', 2018, '13456787654');
INSERT INTO `student` VALUES ('2018126', 'zhange126', '张二', 2018, '13456789012');

-- ----------------------------
-- Table structure for teacheruser
-- ----------------------------
DROP TABLE IF EXISTS `teacheruser`;
CREATE TABLE `teacheruser`  (
  `tid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cid` int(11) NOT NULL,
  `cname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`tid`, `cid`) USING BTREE,
  INDEX `cid`(`cid`) USING BTREE,
  INDEX `cname`(`cname`) USING BTREE,
  INDEX `tid`(`tid`) USING BTREE,
  INDEX `tid_2`(`tid`, `tname`) USING BTREE,
  INDEX `tname`(`tname`) USING BTREE,
  CONSTRAINT `cid` FOREIGN KEY (`cid`) REFERENCES `course` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cname` FOREIGN KEY (`cname`) REFERENCES `course` (`cname`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of teacheruser
-- ----------------------------
INSERT INTO `teacheruser` VALUES ('200123', 'hez123', '何哲', 10, '数据库', '16688945678');
INSERT INTO `teacheruser` VALUES ('200124', 'keye124', '柯叶', 20, '计算机', '12345678812');
INSERT INTO `teacheruser` VALUES ('200125', 'zhhe125', '张祐', 30, '软件工程导论', '13456787654');
INSERT INTO `teacheruser` VALUES ('200126', 'wangy126', '王悦', 20, '计算机', '16868746765');

-- ----------------------------
-- View structure for adminquestion
-- ----------------------------
DROP VIEW IF EXISTS `adminquestion`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `adminquestion` AS select `question`.`qutid` AS `qutid`,`question`.`qid` AS `qid`,`question`.`qcontcnt` AS `qcontcnt`,`question`.`aoption` AS `aoption`,`question`.`bopion` AS `bopion`,`question`.`coption` AS `coption`,`question`.`doption` AS `doption`,`question`.`qanswer` AS `qanswer`,`question`.`pid` AS `pid`,`question`.`fz` AS `fz`,`question`.`tid` AS `tid`,`question`.`teacher` AS `teacher` from `question`;

-- ----------------------------
-- View structure for adminscore
-- ----------------------------
DROP VIEW IF EXISTS `adminscore`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `adminscore` AS select `score`.`cid` AS `cid`,`score`.`cname` AS `cname`,`score`.`pid` AS `pid`,`score`.`pname` AS `pname`,`score`.`sid` AS `sid`,`score`.`name` AS `name`,`score`.`grade` AS `grade`,`score`.`score` AS `score` from `score`;

-- ----------------------------
-- View structure for adminstu
-- ----------------------------
DROP VIEW IF EXISTS `adminstu`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `adminstu` AS select `student`.`sid` AS `sid`,`student`.`password` AS `password`,`student`.`name` AS `name`,`student`.`grade` AS `grade`,`student`.`phone` AS `phone` from `student`;

-- ----------------------------
-- View structure for admintea
-- ----------------------------
DROP VIEW IF EXISTS `admintea`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `admintea` AS select `teacheruser`.`tid` AS `tid`,`teacheruser`.`password` AS `password`,`teacheruser`.`tname` AS `tname`,`teacheruser`.`cid` AS `cid`,`teacheruser`.`cname` AS `cname`,`teacheruser`.`phone` AS `phone` from `teacheruser`;

-- ----------------------------
-- View structure for ckpaper
-- ----------------------------
DROP VIEW IF EXISTS `ckpaper`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `ckpaper` AS select `paper`.`pid` AS `pid`,`paper`.`cid` AS `cid`,`paper`.`cname` AS `cname`,`paper`.`pname` AS `pname`,`paper`.`tid` AS `tid`,`paper`.`tname` AS `tname` from `paper`;

SET FOREIGN_KEY_CHECKS = 1;
