package edu.nenu.onlineExam.score.dao;

import java.util.ArrayList;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import edu.nenu.onlineExam.grade.entity.GRade;
import edu.nenu.onlineExam.paper.entity.PAper;
import edu.nenu.onlineExam.score.entity.Score;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.utils.PageHibernateCallback;

public class ScoreDao extends HibernateDaoSupport {

	public Score ckcj(Score score) {
		List<Score> list = (List<Score>) this.getHibernateTemplate().findByExample(score, 0, 1);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public void upscore(Score score, String npscore) {
		List<Score> list = (List<Score>) this.getHibernateTemplate().findByExample(score, 0, 1);
		if (list != null && list.size() > 0) {
			Score newScore = list.get(0);
			newScore.setScore(npscore);
			this.getHibernateTemplate().save(newScore);

		}
	}
	
	public int findCountPid(Integer pid) {
		String hql = "select count(*) from Score p where s.paper.teacherUser.pid= ?";
		List<Long> list = (List<Long>) this.getHibernateTemplate().find(hql, new Object[]{pid});
		if(list != null && list.size()>0){
			return list.get(0).intValue();
		}
		return 0;
	}
		
	public List<Score> findByPagePid(Integer pid, int begin, int limit) {
		//SELECT s.* from paper p, course c, student s where p.pid = c.pid and c.cid = s.cid and p.pid = 101
		String hql = "select s from Student s join s.course c join p.paper p where p.pid = ? order by s.sid";
		//��ҳʵ��
		List<Score> list = this.getHibernateTemplate().execute(new PageHibernateCallback<Student>(hql, new Object[]{tid}, begin, limit));
		List<Score> listsco = new ArrayList<Score>();
		String hql2 = null;
		for(int i=0; i<list.size();i++){
			Student sco = list.get(i);
			hql2 = "from PAper where pid = ?";
			List<PAper> listpaper = (List<PAper>) this.getHibernateTemplate().find(hql2, new Object[] {list.get(i).getPaper().getPid()});
			if(listpaper!=null && listpaper.size()>0){
				sco.setPaper(listpaper.get(0));
			}
			listsco.add(sco);
		}
		return listsco;
	}

	private Object getHibernateTemplate() {
		// TODO �Զ����ɵķ������
		return null;
	}

	public List<PAper> ckpaper(Integer pid) {
		String hql = "from PAper where pid = ?";
		List<CoUrse> list = (List<PAper>) this.getHibernateTemplate().find(hql, pid);
		return list;
		
	}
 
	public Student finBySid(Integer sid) {
		String hql = "from Student where sid = ?";
		List<Student> list = (List<Student>) this.getHibernateTemplate().find(hql, sid);
		if(list!=null && list.size()>0){
			return list.get(0);
		}
		return null;
	}
	//����ѧ���ɼ���Ϣ
	public void addScortSX(Student student, CoUrse course,PAper paper,String score) {
			String hql = "from CoUrse where cid = ?";
			List<CoUrse> list = (List<CoUrse>) this.getHibernateTemplate().find(hql, cid);
		    CoUrse course = null;
			if(list!=null && list.size()>0){
				course = list.get(0);
			}
			student.setCourse(course);
			this.getHibernateTemplate().save(student);
		
		String hql1 = "from PAper where pid = ?";
		List<PAper> list1 = (List<PAper>) this.getHibernateTemplate().find(hql1, pid);
	    PAper paper = null;
		if(list1!=null && list1.size()>0){
			paper = list1.get(0);
		}
		score.setPaper(paper);
		 this.getHibernateTemplate()).save(score);
	}
	public void addStudentSX(Student student, Integer cid,Integer gid) {
		String hql = "from CoUrse where cid = ?";
		List<CoUrse> list = (List<CoUrse>) this.getHibernateTemplate().find(hql, cid);
	    CoUrse course = null;
		if(list!=null && list.size()>0){
			course = list.get(0);
		}
		student.setCourse(course);
		this.getHibernateTemplate().save(student);
	}
	//����ѧ��ɾ��ѧ����Ϣ
	public void deleteStudent(Integer sid) {
		
		String hql2 = "from Student where sid = ?";
		List<Student> liststu = (List<Student>) this.getHibernateTemplate().find(hql2, sid);
		this.getHibernateTemplate().delete(liststu.get(0));
	}
}

