package edu.nenu.onlineExam.adminuser.service;
import org.springframework.transaction.annotation.*;

import edu.nenu.onlineExam.adminuser.dao.AdminUserDao;
import edu.nenu.onlineExam.adminuser.entity.AdminUser;

@Transactional
public class AdminUserService {

	private AdminUserDao adminUserDao;

	public void setAdminUserDao(AdminUserDao adminUserDao) {
		this.adminUserDao = adminUserDao;
	}
	
	public AdminUser login(AdminUser admin)
	{
		return adminUserDao.login(admin);
	}

	public void uppw(AdminUser admin, String npw) {
		 adminUserDao.uppwd(admin, npw);
		
	}
	
}
