package edu.nenu.onlineExam.student.service;

import java.util.List;


import org.springframework.transaction.annotation.Transactional;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.dao.StudentDao;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.teacheruser.dao.TeacherUserDao;
import edu.nenu.onlineExam.utils.PageBean;
@Transactional
public class StudentService {

	private StudentDao studentDao;

 	public StudentDao getStudentDao() {
		return studentDao;
	}

	public void setStudentDao(StudentDao studentDao) {
		this.studentDao = studentDao;
	}

	public Student login(Student student) {
		return studentDao.login(student);
	}

	public void uppw(Student student, String npw) {
		studentDao.uppwd(student, npw);
	}

	public PageBean<Student> ckStudent(Integer tid, int page) {
		PageBean<Student> pageBean = new PageBean<Student>();
		// ���õ�ǰҳ��
		pageBean.setPage(page);
		// ����ÿҳ��ʾ�ļ�¼��
		int limit = 3;
		pageBean.setLimit(limit);
		// �����ܵļ�¼��
		int totalCount = 0;
		totalCount = studentDao.findCountTid(tid);
		pageBean.setTotalCount(totalCount);
		// �����ܵ�ҳ��
		int totalPage = 0;
		if (totalCount % limit == 0) {
			totalPage = totalCount / limit;
		} else {
			totalPage = totalCount / limit + 1;
		}
		pageBean.setTotalPage(totalPage);
		// ÿҳ��ʾ�����ݼ���
		// ��������¼��ʼ
		int begin = (page - 1) * limit;
		pageBean.setList(list);
		return pageBean;
	   public List<CoUrse> ckcourse(Integer tid) {
			
			return studentDao.ckcourse(tid);
		}
	 
	 //����ѧ�Ų�ѯѧ���Ƿ����
	 		public Student findBySid(Integer sid) {
	 			return StudentDao.finBySid(sid);
	 		}
	 		//����ѧ����Ϣʵ��
	 		public void addStudentSX(Student student,Integer gid,Integer cid) {
	 			StudentDao.addStudentSX(student, gid,cid);	
	 		}
	         //ע��
	 		public void regStudentSX(Student student, Integer gid,Integer cid) {
	 			StudentDao.regStudentSX(student,gid,cid);	
	 		}
	 		//����ѧ��ɾ��ѧ����Ϣ
	 		public void deleteStudent(Integer sid) {
	 			studentDao.deleteStudent(sid);
	 		}
	 		

		public static List<Student> findByPageTid(Integer tid, int begin, int limit) {
			// TODO �Զ����ɵķ������
			return  null;
		}
		
		
	}
