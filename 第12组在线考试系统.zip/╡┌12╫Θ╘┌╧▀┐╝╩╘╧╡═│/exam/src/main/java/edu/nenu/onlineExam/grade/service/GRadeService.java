package edu.nenu.onlineExam.grade.service;

import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import edu.nenu.onlineExam.course.dao.CoUrseDao;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.grade.dao.GRadeDao;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.dao.StudentDao;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.utils.PageBean;
@Transactional
public class GRadeService {

	private    GRadeDao gradeDao;

 	public GRadeDao getGRadeDao() {
		return gradeDao;
	}

	public void setGRadeDao(GRadeDao gradeDao) {
		this.gradeDao = gradeDao;
	}

	public PageBean<Student> ckStudent(Integer tid, int page) {
		PageBean<Student> pageBean = new PageBean<Student>();
		// ���õ�ǰҳ��
		pageBean.setPage(page);
		// ����ÿҳ��ʾ�ļ�¼��
		int limit = 3;
		pageBean.setLimit(limit);
		// �����ܵļ�¼��
		int totalCount = 0;
		totalCount = studentDao.findCountTid(tid);
		pageBean.setTotalCount(totalCount);
		// �����ܵ�ҳ��
		int totalPage = 0;
		if (totalCount % limit == 0) {
			totalPage = totalCount / limit;
		} else {
			totalPage = totalCount / limit + 1;
		}
		pageBean.setTotalPage(totalPage);
		// ÿҳ��ʾ�����ݼ���
		// ��������¼��ʼ
		int begin = (page - 1) * limit;
		List<Student> list = StudentService.findByPageTid(tid, begin, limit);
		pageBean.setList(list);
		return pageBean;
	}
	
	 
		//����ѧ�Ų�ѯѧ���Ƿ����
		public Student findBySid(Integer sid) {
			return StudentDao.finBySid(sid);
		}
		//����ѧ����Ϣʵ��
		public void addStudentSX(Student student,Integer gid,Integer cid) {
			StudentDao.addStudentSX(student, gid,cid);	
		}
        //ע��
		public void regStudentSX(Student student, Integer gid,Integer cid) {
			StudentDao.regStudentSX(student,gid,cid);	
		}
		//����ѧ��ɾ��ѧ����Ϣ
		public void deleteStudent(Integer sid) {
			studentDao.deleteStudent(sid);
		}
		
		
	}
