package edu.nenu.onlineExam.student.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import edu.nenu.onlineExam.bj.entity.BJ;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.grade.entity.GRade;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.utils.PageHibernateCallback;

public class StudentDao extends HibernateDaoSupport {

	public Student login(Student student) {
		List<Student> list = (List<Student>) this.getHibernateTemplate().findByExample(student, 0, 1);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public void uppwd(Student student, String npw) {
		List<Student> list = (List<Student>) this.getHibernateTemplate().findByExample(student, 0, 1);
		if (list != null && list.size() > 0) {
			Student newStudent = list.get(0);
			newStudent.setPassword(npw);
			this.getHibernateTemplate().save(newStudent);

		}
	}
	
	public int findCountTid(Integer tid) {
		String hql = "select count(*) from Student s where s.course.teacherUser.tid= ?";
		List<Long> list = (List<Long>)  this.getHibernateTemplate().find(hql, new Object[]{tid});
		if(list != null && list.size()>0){
			return list.get(0).intValue();
		}
		return 0;
	}
		
	public List<Student> findByPageTid(Integer tid, int begin, int limit) {
		//SELECT s.* from teacheruser t, course c, student s where t.tid = c.tid and c.cid = s.cid and t.tid = 200123
		String hql = "select s from Student s join s.course c join b.teacherUser t where t.tid = ? order by s.sid";
		//��ҳʵ��
		List<Student> list = this.getHibernateTemplate().execute(new PageHibernateCallback<Student>(hql, new Object[]{tid}, begin, limit));
		List<Student> liststu = new ArrayList<Student>();
		String hql2 = null;
		for(int i=0; i<list.size();i++){
			Student stu = list.get(i);
			hql2 = "from CoUrse where cid = ?";
			List<CoUrse> listcourse = (List<CoUrse>) this.getHibernateTemplate().find(hql2, new Object[] {list.get(i).getCourse().getCid()});
			if(listcourse!=null && listcourse.size()>0){
				stu.setCourse(listcourse.get(0));
			}
			liststu.add(stu);
		}
		return liststu;
	}

	private Object getHibernateTemplate() {
		// TODO �Զ����ɵķ������
		return null;
	}

	public List<CoUrse> ckcourse(Integer tid) {
		String hql = "from CoUrse where tid = ?";
		List<CoUrse> list = (List<CoUrse>) this.getHibernateTemplate().find(hql, tid);
		return list;
		
	}
 
	public static Student finBySid(Integer sid) {
		String hql = "from Student where sid = ?";
		List<Student> list = (List<Student>) this.getHibernateTemplate().find(hql, sid);
		if(list!=null && list.size()>0){
			return list.get(0);
		}
		return null;
	}
	//����ѧ����Ϣ
	public static void addStudentSX(Student student, Integer cid,Integer gid) {
		String hql = "from CoUrse where cid = ?";
		List<CoUrse> list = (List<CoUrse>) this.getHibernateTemplate().find(hql, cid);
	    CoUrse course = null;
		if(list!=null && list.size()>0){
			course = list.get(0);
		}
		student.setCourse(course);
		this.getHibernateTemplate().save(student);
	}
	//ע��
	public static String regStudentSX(Student student,Integer gid) {
		String hql = "from GRade where gid = ?";
		List<GRade> list = (List<GRade>) this.getHibernateTemplate().find(hql, gid);
		GRade grade = null;
		if(list!=null && list.size()>0){
			grade = list.get(0);
		}
		student.setGrade(grade);
		this.getHibernateTemplate().save(student);
	}
	//����ѧ��ɾ��ѧ��
	public void deleteStudent(Integer sid) {
		
		String hql2 = "from Student where sid = ?";
		List<Student> liststu = (List<Student>) this.getHibernateTemplate().find(hql2, sid);
		this.getHibernateTemplate().delete(liststu.get(0));
	}

	
}

