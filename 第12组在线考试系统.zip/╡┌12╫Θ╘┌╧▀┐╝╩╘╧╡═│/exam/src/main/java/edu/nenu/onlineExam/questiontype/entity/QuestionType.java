package edu.nenu.onlineExam.questiontype.entity;

import java.util.HashSet;
import java.util.Set;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.question.entity.Question;

public class QuestionType {
	private Integer qtid;    //��������id
	private String qtname;	 //������������
	private Integer fz;	 //�������ͷ���
	private CoUrse course;
	private Set<Question> questions = new HashSet<Question>();
	public Integer getQtid() {
		return qtid;
	}
	public void setQtid(Integer qtid) {
		this.qtid = qtid;
	}
	public String getQtname() {
		return qtname;
	}
	public void setQtname(String qtname) {
		this.qtname = qtname;
	}
	public Integer getFz() {
		return fz;
	}
	public void setFz(Integer fz) {
		this.fz = fz;
	}
	public CoUrse getCourse() {
		return course;
	}
	public void setCourse(CoUrse course) {
		this.course = course;
	}
	public Set<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}
	
	
}
