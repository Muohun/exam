package edu.nenu.onlineExam.student.action;

import java.io.IOException;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
import edu.nenu.onlineExam.utils.PageBean;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.utils.PageBean;

public class StudentAction extends ActionSupport implements ModelDriven<Student>, SessionAware{
	private Student student = new Student();

	private StudentService studentService;

	public void setStudentService(StudentService StudentService) {
		this.studentService = StudentService;

	}
	
	public Student getModel() {
		return student;
	}
  
	private String npw;
	
	private int page;
	
	public void setPage(int page) {
		this.page = page;
	}
	
		public String getNpw() {
		return npw;
	}
	private Integer tid;

		public void setTid(Integer tid) {
			this.tid = tid;
		}
	
	private Integer cid;
		
	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}
	private Integer gid;
	
	public Integer getGid() {
		return gid;
	}

	public void setGid(Integer gid) {
		this.gid = gid;
	}
	public void setNpw(String npw) {
		this.npw = npw;
	}

		public String checkLogin() {
			Student existStudent = studentService.login(student);
			if (existStudent != null)
			{
				ServletActionContext.getRequest().getSession().setAttribute("existStudent", existStudent);
				return "success";
			}else
			{
				return "error";
			}
			
	}
	
		public String uppw() {
			
			studentService.uppw(student,npw);
          	
			return "success";
			
		}
			
        public String logoff() {
        	ServletActionContext.getRequest().getSession().invalidate();
        	return "success";
        }
        
    	public String ckAllStudent(){
    		PageBean<Student> pageBean = studentService.ckStudent(tid,page);
    		//��PageBean����ֵջ��
    		ActionContext.getContext().getValueStack().set("pageBean", pageBean);		
    		return "ckAllStudentSucess";
    	}
	
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
	
	}
	
	public String addStudent(){
		List<CoUrse> list =studentService.ckcourse(tid);
		ActionContext.getContext().getValueStack().set("listcourse", list);
		return "addStudent";
	}
	
	public String addStudentSX(){
		studentService.addStudentSX(student,cid);
		return "success";
	}
	public String regStudent(){
		List<CoUrse> list =studentService.ckcourse(tid);
		ActionContext.getContext().getValueStack().set("listcourse", list);
		return "regStudent";
	}
	
	public String regStudentSX(){
		studentService.addStudentSX(student,cid);
		return "success";
	}
 
	public String deleteStudent(){
		studentService.deleteStudent(student.getSid());
		PageBean<Student> pageBean = studentService.ckStudent(tid,page);
		//��PageBean����ֵջ��
		ActionContext.getContext().getValueStack().set("pageBean", pageBean);		
		return "addStudent";
	}
	
	/**
	 * AJAX�����첽У��༶����ִ�з���
	 * @return
	 * @throws IOException 
	 */
	public String findBySid() throws IOException{
		Student existStudent = studentService.findBySid(student.getSid());
		//���response������ҳ�����
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=UTF-8");
		//�ж�
		if(existStudent != null){
			//��ѯ���γ̣��γ�������
			response.getWriter().print("t");
		}else{
			//û�в鵽�ÿγ̣��γ��������ڣ�����ʹ��
			response.getWriter().print("f");
		}
		return NONE;
	}
}