package edu.nenu.onlineExam.teacheruser.action;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import edu.nenu.onlineExam.student.action.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
import edu.nenu.onlineExam.teacheruser.service.TeacherUserService;
import edu.nenu.onlineExam.utils.PageBean;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class TeacherAction extends ActionSupport implements ModelDriven<TeacherUser>,SessionAware{
	//ģ������ʹ�õĶ���
	private TeacherUser teacherUser = new TeacherUser();
		public TeacherUser getModel() {
		return teacherUser;
	}
	//ע��TeacherService
	private TeacherUserService teacherUserService;

	public void setTeacherUserService(TeacherUserService teacherUserService) {
		this.teacherUserService = teacherUserService;
	}
	public String ckAllTeacherUser(){
		PageBean<TeacherUser> pageBean = TeacherUserService.ckTeacherUser(tid,page);
		//��PageBean����ֵջ��
		ActionContext.getContext().getValueStack().set("pageBean", pageBean);		
		return "ckAllTeacherUserSucess";
	}

public void setSession(Map<String, Object> session) {
	// TODO Auto-generated method stub

}

public String addTeacherUser(){
	List<edu.nenu.onlineExam.course.entity.CoUrse> list =TeacherUserService.ckcourse(tid);
	ActionContext.getContext().getValueStack().set("listcourse", list);
	return "addTeacherUser";
}

public String addTeacherUserSX(){
	teacherUserService.addTeacherUserSX(teacherUser,cid);
	return "success";
}
public String regTeacherUser(){
	List<CoUrse> list =teacherUserService.ckcourse(tid);
	ActionContext.getContext().getValueStack().set("listcourse", list);
	return "regTeacherUser";
}

public String regTeacherUserSX(){
	teacherUserService.addTeacherSX(teacherUser,cid);
	return "success";
}

public String deleteTeacher(){
	teacherUserService.deleteTeacherUser(teacherUser.getTid());
	PageBean<TeacherUser> pageBean = teacherUserService.ckTeacherUser(tid,page);
	//��PageBean����ֵջ��
	ActionContext.getContext().getValueStack().set("pageBean", pageBean);		
	return "addteacheruser";
}
	//��ȡ������
	private String npw ;

	public void setTeacherUser(TeacherUser teacherUser) {
		this.teacherUser = teacherUser;
	}

	public void setNpw(String npw) {
		this.npw = npw;
	}

	public String tlogin(){
		return "login";
	}
	
	//��֤��ʦ��ź������Ƿ���ȷ
	public String login(){
		TeacherUser existTeacher = teacherUserService.login(teacherUser);
		//�ж��û��Ƿ����
		if(existTeacher == null){
			this.addActionError("��ʦ��Ż��������");
			return "error";
		}else{
			ServletActionContext.getRequest().getSession().setAttribute("existTeacher", existTeacher);
				return "success";	
		}		
	}
	//��ȫ�˳����session
	public String sessionDestory(){
		ServletActionContext.getRequest().getSession().invalidate();
		return "sessionDestoryteacher";
	}

 
	//�޸�����ʵ��
 
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return "NONE";
	}

	public void setSession(Map<String, Object> arg0) {
	}
	
	
}
