package edu.nenu.onlineExam.paper.service;

import java.util.List;


import org.springframework.transaction.annotation.Transactional;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.paper.dao.PaperDao;
import edu.nenu.onlineExam.paper.entity.PAper;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.dao.StudentDao;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.utils.PageBean;
@Transactional
public class PaperService {

	private PaperDao paperDao;

 	public PaperDao getPaperDao() {
		return paperDao;
	}

	public void setPaperDao(PaperDao paperDao) {
		this.paperDao = paperDao;
	}

	public PAper editor(PAper paper) {
		return paperDao.editor(paper);
	}

	public void ced(PAper paper, String ed) {
		PaperDao.ced(paper, ed);
	}

	public PageBean<PAper> ckPaper(Integer tid, int page) {
		PageBean<Student> pageBean = new PageBean<Student>();
		// ���õ�ǰҳ��
		pageBean.setPage(page);
		// ����ÿҳ��ʾ�ļ�¼��
		int limit = 3;
		pageBean.setLimit(limit);
		// �����ܵļ�¼��
		int totalCount = 0;
		totalCount = paperDao.findCountTid(tid);
		pageBean.setTotalCount(totalCount);
		// �����ܵ�ҳ��
		int totalPage = 0;
		if (totalCount % limit == 0) {
			totalPage = totalCount / limit;
		} else {
			totalPage = totalCount / limit + 1;
		}
		pageBean.setTotalPage(totalPage);
		// ÿҳ��ʾ�����ݼ���
		// ��������¼��ʼ
		int begin = (page - 1) * limit;
		List<Paper> list = paperDao.findByPageTid(tid, begin, limit);
		pageBean.setList(list);
		return pageBean;
	}
	   public List<CoUrse> ckcourse(Integer tid) {
			
			return paperDao.ckcourse(tid);
		}
	 
		//��ѯ�Ծ��Ƿ����
		public PAper findByPid(Integer pid) {
			return PaperDao.finByPid(pid);
		}
		//�����Ծ���Ϣʵ��
		public void addPaperSX(PAper paper,Integer cid) {
			paperDao.addPaperSX(paper, cid);	
		}
		//����ѧ��ɾ��ѧ����Ϣ
		public void deletePaper(Integer pid) {
			paperDao.deletePaper(pid);
		}
		
		
	}
