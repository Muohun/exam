package edu.nenu.onlineExam.questiontype.action;

import java.io.IOException;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.course.service.CoUrseService;
import edu.nenu.onlineExam.grade.entity.GRade;
import edu.nenu.onlineExam.question.entity.Question;
import edu.nenu.onlineExam.question.service.QuestionService;
import edu.nenu.onlineExam.questiontype.entity.QuestionType;
import edu.nenu.onlineExam.student.dao.StudentDao;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
import edu.nenu.onlineExam.utils.PageBean;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.utils.PageBean;

public class  QuestionTypeAction<QuestionTypeService> extends ActionSupport implements ModelDriven<QuestionType>, SessionAware{
	private  QuestionType questiontype = new QuestionType();

	private  QuestionTypeService  questiontypeService;


	public void setQuestionTypeService(QuestionTypeService questiontypeService) {
		this.questiontypeService = questiontypeService;

	}
	
	public QuestionType getModel() {
		return questiontype;
	}
  
	
	private Integer tid;

		public void setTid(Integer tid) {
			this.tid = tid;
		}
	
	private Integer cid;
		
	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}
			
        public String logoff() {
        	ServletActionContext.getRequest().getSession().invalidate();
        	return "success";
        }
        
	
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
	
	}
	
	}
}