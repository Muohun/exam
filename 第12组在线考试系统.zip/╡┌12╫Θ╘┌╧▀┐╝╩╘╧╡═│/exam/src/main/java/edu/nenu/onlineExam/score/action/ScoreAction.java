package edu.nenu.onlineExam.score.action;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.nenu.onlineExam.bj.entity.BJ;
import edu.nenu.onlineExam.score.entity.Score;
import edu.nenu.onlineExam.student.action.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
import edu.nenu.onlineExam.utils.PageBean;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.nenu.onlineExam.bj.entity.BJ;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.utils.PageBean;

public class ScoreAction extends ActionSupport implements ModelDriven<Score>, SessionAware{
	private Score score = new Score();

	private ScoreService scoreService;

	public void setScoreService(ScoreService ScoreService) {
		this.scoreService = scoreService;

	}
	
	public Score getModel() {
		return score;
	}
  
	private String npscore;
	
	private int page;
	
	public void setPage(int page) {
		this.page = page;
	}
	
		public String getNpscore() {
		return npscore;
	}
	private Integer sid;

		public void setSid(Integer sid) {
			this.sid = sid;
		}
	
	private Integer pid;
		
	public Integer getPaperid() {
		return pid;
	}

	public void setPaperid(Integer pid) {
		this.pid = pid;
	}

	public void setNpscore(String npscore) {
		this.npscore = npscore;
	}

		public String checkCkcj() {
			Student existScore = scoreService.ckcj(score);
			if (existStudent != null)
			{
				ServletActionContext.getRequest().getSession().setAttribute("existScore", existScore);
				return "success";
			}else
			{
				return "error";
			}
			
	}
	
		public String upscore() {
			
			scoreService.upscore(score,npscore);
          	
			return "success";
			
		}
			
        public String logoff() {
        	ServletActionContext.getRequest().getSession().invalidate();
        	return "success";
        }
        
    	public String ckcj(){
    		PageBean<Score> pageBean = scoreService.ckScore(pid,page);
    		//��PageBean����ֵջ��
    		ActionContext.getContext().getValueStack().set("pageBean", pageBean);		
    		return "ckAllStudentSucess";
    	}
	
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
	
	}
	
	public String addScore(){
		List<> list =scoreService.ckpaper(pid);
		ActionContext.getContext().getValueStack().set("listcourse", list);
		return "ckcj";
	}
	
	public String addScoreSX(){
		scoreService.addStudentSX(score,sid);
		return "success";
	}
 
	public String deleteScore(){
		scoreService.deleteScore(score.getScore());
		PageBean<Score> pageBean = scoreService.ckStudent(pid,page);
		//��PageBean����ֵջ��
		ActionContext.getContext().getValueStack().set("pageBean", pageBean);		
		return "ckcj";
	}
	
	/**
	 * AJAX�����첽У���ִ�з���
	 * @return
	 * @throws IOException 
	 */
	public String findBySid() throws IOException{
		Score existScore = scoreService.findBySid(score.getScore());
		//���response������ҳ�����
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=UTF-8");
		//�ж�
		if(existScore != null){
			
			response.getWriter().print("t");
		}else{
			
			response.getWriter().print("f");
		}
		return NONE;
	}
