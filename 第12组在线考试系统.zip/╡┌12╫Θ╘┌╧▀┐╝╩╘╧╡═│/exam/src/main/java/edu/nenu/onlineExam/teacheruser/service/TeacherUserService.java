package edu.nenu.onlineExam.teacheruser.service;

import org.springframework.transaction.annotation.Transactional;

import edu.nenu.onlineExam.student.dao.StudentDao;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.teacheruser.dao.TeacherUserDao;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
@Transactional
public class TeacherUserService {
	private TeacherUserDao teacherUserDao;

	public TeacherUser login(TeacherUser teacherUser) {
		
		return teacherUserDao.login(teacherUser);
	}

	public TeacherUserDao getTeacherUserDao() {
		return teacherUserDao;
	}

	public void setTeacherUserDao(TeacherUserDao teacherUserDao) {
		this.teacherUserDao = teacherUserDao;
	}
	//����ѧ�Ų�ѯѧ���Ƿ����
			public Student findBySid(Integer sid) {
				return StudentDao.finBySid(sid);
			}
			//����ѧ����Ϣʵ��
			public void addStudentSX(Student student, Integer cid,Integer gid) {
				StudentDao.addStudentSX(student,cid, gid);	
			}
	        //ע��
			public void regTeacherUserSX(TeacherUser teacheruser, Integer cid) {
				TeacherUserDao.regTeacherUserSX(teacheruser,cid);	
			}
			//����ѧ��ɾ��ѧ����Ϣ
			public void deleteStudent(Integer sid) {
				StudentDao.deleteStudent(sid);
			}SX(Student student, Integer gid) {
				studentDao.regStudentSX(student,gid);	
			}
			//����ѧ��ɾ��ѧ����Ϣ
			public void deleteStudent(Integer sid) {
				studentDao.deleteStudent(sid);
			}
 
}
