package edu.nenu.onlineExam.adminuser.action;

import java.util.Map;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.nenu.onlineExam.adminuser.entity.AdminUser;
import edu.nenu.onlineExam.adminuser.service.AdminUserService;

public class AdminUserAction extends ActionSupport implements ModelDriven<AdminUser>, SessionAware{
	private AdminUser admin = new AdminUser();

	private AdminUserService adminUserService;

	public void setAdminUserService(AdminUserService adminUserService) {
		this.adminUserService = adminUserService;

	}
	
	public AdminUser getModel() {
		return admin;
	}
  
	private String npw;
	
 
	
		public String getNpw() {
		return npw;
	}

	public void setNpw(String npw) {
		this.npw = npw;
	}

		public String checkLogin() {
			AdminUser existAdmin = adminUserService.login(admin);
			if (existAdmin != null)
			{
				ServletActionContext.getRequest().getSession().setAttribute("existAdmin", existAdmin);
				return "success";
			}else
			{
				return "error";
			}
			
	}
				
		public String uppw() {
			
			adminUserService.uppw(admin,npw);
          	
			return "success";
			
		}
			
        public String logoff() {
        	ServletActionContext.getRequest().getSession().invalidate();
        	return "success";
        }
        
	
	
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
	
	}
}
