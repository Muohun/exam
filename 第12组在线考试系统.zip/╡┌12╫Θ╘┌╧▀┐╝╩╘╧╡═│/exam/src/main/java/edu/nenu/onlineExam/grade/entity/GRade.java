package edu.nenu.onlineExam.grade.entity;

import java.util.HashSet;
import java.util.Set;

import edu.nenu.onlineExam.score.entity.Score;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;

public class GRade {


	private Integer gid;
	private String gname;
	private TeacherUser teacherUser;
	private Set<Student> students = new HashSet<Student>();
	private Set<Score> scores = new HashSet<Score>();
	public Integer getGid() {
		return gid;
	}

	public void setGid(Integer gid) {
		this.gid = gid;
	}

	public String getGname() {
		return gname;
	}

	public void setGname(String gname) {
		this.gname = gname;
	}
	public Set<Score> getScores() {
		return scores;
	}

	public void setScores(Set<Score> scores) {
		this.scores  = scores;
	}
	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	public TeacherUser getTeacherUser() {
		return teacherUser;
	}

	public void setTeacherUser(TeacherUser teacherUser) {
		this.teacherUser = teacherUser;
	}

	
	
}
