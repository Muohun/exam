package edu.nenu.onlineExam.course.entity;

import java.util.HashSet;
import java.util.Set;

import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;

public class CoUrse {


	private Integer cid;
	private String cname;
	private TeacherUser teacherUser;
	private Set<Student> students = new HashSet<Student>();
	
	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	public TeacherUser getTeacherUser() {
		return teacherUser;
	}

	public void setTeacherUser(TeacherUser teacherUser) {
		this.teacherUser = teacherUser;
	}

	
	
}
