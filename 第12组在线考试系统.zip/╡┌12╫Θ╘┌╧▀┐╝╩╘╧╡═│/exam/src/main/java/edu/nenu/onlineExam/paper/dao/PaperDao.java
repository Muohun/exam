package edu.nenu.onlineExam.paper.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import edu.nenu.onlineExam.bj.entity.BJ;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.grade.entity.GRade;
import edu.nenu.onlineExam.paper.entity.PAper;
import edu.nenu.onlineExam.paper.service.Paper;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.utils.PageHibernateCallback;

public class PaperDao extends HibernateDaoSupport {
	public PAper editor(PAper paper) {
		// TODO �Զ����ɵķ������
		List<PAper> list = (List<PAper>) this.getHibernateTemplate().findByExample(paper, 0, 1);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}
	public static void ced(PAper paper, String ed) {
		// TODO �Զ����ɵķ������
		List<PAper> list = (List<PAper>) this.getHibernateTemplate().findByExample(paper, 0, 1);
		if (list != null && list.size() > 0) {
			PAper newPAper = list.get(0);
			newPAper.setPname(ed);
			this.getHibernateTemplate().save(newPAper);
			
		}
	}
	
	public int findCountTid(Integer tid) {
		String hql = "select count(*) from PAper p where p.course.teacherUser.tid= ?";
		List<Long> list = (List<Long>)  this.getHibernateTemplate().find(hql, new Object[]{tid});
		if(list != null && list.size()>0){
			return list.get(0).intValue();
		}
		return 0;
	}
		
	public List<PAper> findByPageTid(Integer tid, int begin, int limit) {
		//SELECT s.* from teacheruser t, course c, paper p where t.tid = c.tid and c.cid = s.cid and t.tid = 200123
		String hql = "select p from PAper p join p.course c join b.teacheruser t where t.tid = ? order by s.sid";
		//��ҳʵ��
		List<PAper> list = this.getHibernateTemplate().execute(new PageHibernateCallback<Student>(hql, new Object[]{tid}, begin, limit));
		List<PAper> listpap = new ArrayList<PAper>();
		String hql2 = null;
		for(int i=0; i<list.size();i++){
			PAper pap = list.get(i);
			hql2 = "from CoUrse where cid = ?";
			List<CoUrse> listcourse = (List<CoUrse>) this.getHibernateTemplate().find(hql2, new Object[] {list.get(i).getCourse().getCid()});
			if(listcourse!=null && listcourse.size()>0){
				pap.setCourse(listcourse.get(0));
			}
			listpap.add(pap);
		}
		return listpap;
	}

	private Object getHibernateTemplate() {
		// TODO �Զ����ɵķ������
		return null;
	}

	public List<CoUrse> ckcourse(Integer tid) {
		String hql = "from CoUrse where tid = ?";
		List<CoUrse> list = (List<CoUrse>) this.getHibernateTemplate().find(hql, tid);
		return list;
		
	}
 
	public static Student finBySid(Integer sid) {
		String hql = "from Student where sid = ?";
		List<Student> list = (List<Student>) this.getHibernateTemplate().find(hql, sid);
		if(list!=null && list.size()>0){
			return list.get(0);
		}
		return null;
	}
	//����ѧ����Ϣ
	public void addPaperSX(PAper paper, Integer cid) {
		// TODO �Զ����ɵķ������
		String hql = "from CoUrse where cid = ?";
		List<CoUrse> list = (List<CoUrse>) this.getHibernateTemplate().find(hql, cid);
	    CoUrse course = null;
		if(list!=null && list.size()>0){
			course = list.get(0);
		}
		paper.setCourse(course);
		this.getHibernateTemplate().save(paper);
	}
	//����ѧ��ɾ��ѧ��
	public void deleteStudent(Integer sid) {
		
		String hql2 = "from Student where sid = ?";
		List<Student> liststu = (List<Student>) this.getHibernateTemplate().find(hql2, sid);
		this.getHibernateTemplate().delete(liststu.get(0));
	}

	

	

	

	public void deletePaper(Integer pid) {
		// TODO �Զ����ɵķ������
		
	}

	public static PAper finByPid(Integer pid) {
		// TODO �Զ����ɵķ������
		return null;
	}
}

