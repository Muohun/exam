package edu.nenu.onlineExam.score.entity;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.paper.*;
import edu.nenu.onlineExam.paper.entity.PAper;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.grade.entity.GRade;
import edu.nenu.onlineExam.grade.*;
public class Score {
	private CoUrse course;
	private PAper paper;
	private Student student;
	private String score;
	private GRade grade;
	
	public CoUrse getCourse() {
		return course;
	}
	public void setCourse(CoUrse course) {
		this.course = course;
	}
	
	public PAper getPaper() {
		return paper;
	}
	public void setPaper(PAper paper) {
		this.paper = paper;
	}
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public GRade getGrade() {
		return grade;
	}
	
	public void setGrade(GRade grade) {
		this.grade = grade;
	}
	
}
