package edu.nenu.onlineExam.question.entity;

import java.util.Date;

import edu.nenu.onlineExam.questiontype.entity.QuestionType;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
 
public class Question {
	private Integer qid;		//����id
	private String qcontent;	//��������
	private String aoption;		//ѡ��a
	private String boption;		//ѡ��b
	private String coption;		//ѡ��c
	private String doption;		//ѡ��d
	private String qanswer;		//��
	private String qanalysis;	//����
	private String oword;		//�ؼ���
	private String qscope;		//���ⷶΧ
	private String qdifficulty; //�����Ѷ�
	private Date qdate;			//������������
	private QuestionType questionType;	//��������
	private TeacherUser teacher;	//���ӽ�ʦ
	public Integer getQid() {
		return qid;
	}
	public void setQid(Integer qid) {
		this.qid = qid;
	}
	public String getQcontent() {
		return qcontent;
	}
	public void setQcontent(String qcontent) {
		this.qcontent = qcontent;
	}
	public String getAoption() {
		return aoption;
	}
	public void setAoption(String aoption) {
		this.aoption = aoption;
	}
	public String getBoption() {
		return boption;
	}
	public void setBoption(String boption) {
		this.boption = boption;
	}
	public String getCoption() {
		return coption;
	}
	public void setCoption(String coption) {
		this.coption = coption;
	}
	public String getDoption() {
		return doption;
	}
	public void setDoption(String doption) {
		this.doption = doption;
	}
	public String getQanswer() {
		return qanswer;
	}
	public void setQanswer(String qanswer) {
		this.qanswer = qanswer;
	}
	public String getQanalysis() {
		return qanalysis;
	}
	public void setQanalysis(String qanalysis) {
		this.qanalysis = qanalysis;
	}
	public String getOword() {
		return oword;
	}
	public void setOword(String oword) {
		this.oword = oword;
	}
	public String getQscope() {
		return qscope;
	}
	public void setQscope(String qscope) {
		this.qscope = qscope;
	}
	public String getQdifficulty() {
		return qdifficulty;
	}
	public void setQdifficulty(String qdifficulty) {
		this.qdifficulty = qdifficulty;
	}
	public Date getQdate() {
		return qdate;
	}
	public void setQdate(Date qdate) {
		this.qdate = qdate;
	}
	public QuestionType getQuestionType() {
		return questionType;
	}
	public void setQuestionType(QuestionType questiontype) {
		this.questionType = questiontype;
	}
	public TeacherUser getTeacher() {
		return teacher;
	}
	public void setTeacher(TeacherUser teacher) {
		this.teacher = teacher;
	}
	
}
