package edu.nenu.onlineExam.student.entity;

import java.util.HashSet;
import java.util.Set;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.grade.entity.GRade;
import edu.nenu.onlineExam.questiontype.entity.QuestionType;
import edu.nenu.onlineExam.score.entity.Score;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
public class Student {
	private Integer sid;
	private String password;
	private String name;
	private String phone;
	private CoUrse course;
	private GRade grade;
	private Set<Score> scores = new HashSet<Score>();
	
	public Integer getSid() {
		return sid;
		
	}
	public void setSid(Integer sid) {
		this.sid = sid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public CoUrse getCourse() {
		return course;
	}
	public void setCourse(CoUrse course) {
		this.course = course;
	}
	public GRade getGrade() {
		return grade;
	}
	
	public void setGrade(GRade grade) {
		this.grade = grade;
	}
	
	public Set<Score> getScores() {
		return scores;
	}

	public void setScores(Set<Score> scores) {
		this.scores  = scores;
	}

}
