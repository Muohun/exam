package edu.nenu.onlineExam.questiontype.service;

import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import edu.nenu.onlineExam.course.dao.CoUrseDao;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.grade.dao.GRadeDao;
import edu.nenu.onlineExam.question.dao.QuestionDao;
import edu.nenu.onlineExam.question.entity.Question;
import edu.nenu.onlineExam.question.service.QuestionService;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.dao.StudentDao;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.utils.PageBean;
@Transactional
public class QuestionTypeService<QuestionTypeDao> {

	private   QuestionTypeDao questiontypeDao;

 	public QuestionTypeDao getQuestionTypeDao() {
		return questiontypeDao;
	}

	public void setQuestionTypeDao(QuestionTypeDao questiontypeDao) {
		this.questiontypeDao = questiontypeDao;
	}

	public PageBean<Question> ckQuenstion(Integer qid, int page) {
		PageBean<Question> pageBean = new PageBean<Question>();
		// ���õ�ǰҳ��
		pageBean.setPage(page);
		// ����ÿҳ��ʾ�ļ�¼��
		int limit = 3;
		pageBean.setLimit(limit);
		// �����ܵļ�¼��
		int totalCount = 0;
		totalCount = QuestionDao.findCountQid(qid);
		pageBean.setTotalCount(totalCount);
		// �����ܵ�ҳ��
		int totalPage = 0;
		if (totalCount % limit == 0) {
			totalPage = totalCount / limit;
		} else {
			totalPage = totalCount / limit + 1;
		}
		pageBean.setTotalPage(totalPage);
		// ÿҳ��ʾ�����ݼ���
		// ��������¼��ʼ
		int begin = (page - 1) * limit;
		List<Question> list = QuestionService.findByPageQid(qid, begin, limit);
		pageBean.setList(list);
		return pageBean;
	}
	
	
		//����������Ϣʵ��
		public void addQuestionxzSX(Question question,Integer qid,Integer cid) {
			QuestionDao.addQuestionXZSX(question, qid,cid);	
		}
		public void addQuestionpdSX(Question question,Integer qid,Integer cid) {
			QuestionDao.addQuestionPDSX(question, qid,cid);	
		}
		public void addQuestiontkSX(Question question,Integer qid,Integer cid) {
			QuestionDao.addQuestionTKSX(question, qid,cid);	
		}
       
		//���������ɾ��������Ϣ
		public void delQuestion(Integer qid) {
			QuestionDao.delQuestion(qid);
		}
		
		
	}
