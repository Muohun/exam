package edu.nenu.onlineExam.grade.action;

import java.io.IOException;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.course.service.CoUrseService;
import edu.nenu.onlineExam.grade.entity.GRade;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
import edu.nenu.onlineExam.utils.PageBean;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.utils.PageBean;

public class GRadeAction<GRadeService> extends ActionSupport implements ModelDriven<GRade>, SessionAware{
	private GRade grade = new GRade();

	private GRadeService gradeService;


	public void setGRadeService(GRadeService gradeService) {
		this.gradeService = gradeService;

	}
	
	public GRade getModel() {
		return grade;
	}
  
	
	private Integer tid;

		public void setTid(Integer tid) {
			this.tid = tid;
		}
	
	private Integer gid;
		
	public Integer getGid() {
		return gid;
	}

	public void setGid(Integer gid) {
		this.gid = gid;
	}
			
        public String logoff() {
        	ServletActionContext.getRequest().getSession().invalidate();
        	return "success";
        }
        
	
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
	
	}
	  
	/**
	 * AJAX�����첽У��༶����ִ�з���
	 * @return
	 * @throws IOException 
	 */
	public String findBySid() throws IOException{
		Student existStudent = StudentService.findBySid(course.getSid());
		//���response������ҳ�����
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=UTF-8");
		//�ж�
		if(existStudent != null){
			//��ѯ���γ̣��γ�������
			response.getWriter().print("t");
		}else{
			//û�в鵽�ÿγ̣��γ��������ڣ�����ʹ��
			response.getWriter().print("f");
		}
		return none;
	}
}