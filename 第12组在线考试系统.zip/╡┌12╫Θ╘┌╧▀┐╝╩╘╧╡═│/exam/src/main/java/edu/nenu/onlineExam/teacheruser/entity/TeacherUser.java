package edu.nenu.onlineExam.teacheruser.entity;

import java.util.HashSet;
import java.util.Set;

import edu.nenu.onlineExam.bj.entity.BJ;
import edu.nenu.onlineExam.course.entity.CoUrse;

public class TeacherUser {
	private Integer tid;
	private String tname;
	private String password;
	private String phone;
	private CoUrse course;
	private Set<CoUrse> courses = new HashSet<CoUrse>();
	
	public Integer getTid() {
		return tid;
	}
	public void setTid(Integer tid) {
		this.tid = tid;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Set<CoUrse> getCourses() {
		return courses;
	}
	public void setCourses(Set<CoUrse> courses) {
		this.courses = courses;
	}
	public CoUrse getCourse() {
		// TODO �Զ����ɵķ������
		return course;
	}
	public void setCourse(CoUrse course) {
		this.course = course;
	}


}
