package edu.nenu.onlineExam.paper.action;

import java.io.IOException;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.student.service.StudentService;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
import edu.nenu.onlineExam.utils.PageBean;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.paper.entity.PAper;
import edu.nenu.onlineExam.paper.service.PaperService;
import edu.nenu.onlineExam.utils.PageBean;

public class PaperAction<PaperService> extends ActionSupport implements ModelDriven<PAper>, SessionAware{
	private PAper paper = new PAper();

	private PaperService paperService;

	public void setPaperService(PaperService PaperService) {
		this.paperService = PaperService;

	}
	
	public PAper getModel() {
		return paper;
	}
  
	private Integer tid;

		public void setTid(Integer tid) {
			this.tid = tid;
		}
	
	private Integer cid;

		
	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}
	private String ed;
	
	
	public String geted() {
		return ed;
	}
	public void seted(String ed) {
			this.ed = ed;
	}

		public String checkeditor() {
			PAper existPaper = paperService.editor(paper);
			if (existPaper != null)
			{
				ServletActionContext.getRequest().getSession().setAttribute("existPaper", existPaper);
				return "success";
			}else
			{
				return "error";
			}
			
	}
	
		public String ced() {
			
			((edu.nenu.onlineExam.paper.service.PaperService) paperService).ced(paper,ed);
          	
			return "success";
			
		}
			
        public String logoff() {
        	ServletActionContext.getRequest().getSession().invalidate();
        	return "success";
        }
        
    	public String ckPaper(){
			PageBean<Paper> pageBean = paperService.ckPaper(tid,page);
    		//��PageBean����ֵջ��
    		ActionContext.getContext().getValueStack().set("pageBean", pageBean);		
    		return "ckAllStudentSucess";
    	}
	
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
	
	}
	
	public String addPaper(){
		List<CoUrse> list =paperService.ckcourse(tid);
		ActionContext.getContext().getValueStack().set("listcourse", list);
		return "addPaper";
	}
	
	public String addPaperSX(){
		((edu.nenu.onlineExam.paper.service.PaperService) paperService).addPaperSX(paper,tid);
		return "success";
	}
	public String deletePaper(){
		((edu.nenu.onlineExam.paper.service.PaperService) paperService).deletePaper(paper.getPid());
		PageBean<Student> pageBean = paperService.ckPaper(tid,page);
		//��PageBean����ֵջ��
		ActionContext.getContext().getValueStack().set("pageBean", pageBean);		
		return "addPaper";
	}
	
}