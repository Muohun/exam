package edu.nenu.onlineExam.score.service;

import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import edu.nenu.onlineExam.grade.entity.GRade;
import edu.nenu.onlineExam.score.entity.Score;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.dao.StudentDao;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.utils.PageBean;
@Transactional
public class SocreService {

	private ScoreDao scoreDao;

 	public ScoreDao getScoreDao() {
		return scoreDao;
	}

	public void setScoreDao(ScoreDao scoreDao) {
		this.scoreDao = scoreDao;
	}

	public Score login(Score score) {
		return scoreDao.ckcj(score);
	}

	public void upscore(Score score, String npscore) {
		scoreDao.upscore(score, npscore);
	}

	public PageBean<Score> ckcj(Integer pid, int page) {
		PageBean<Score> pageBean = new PageBean<Score>();
		// ���õ�ǰҳ��
		pageBean.setPage(page);
		// ����ÿҳ��ʾ�ļ�¼��
		int limit = 3;
		pageBean.setLimit(limit);
		// �����ܵļ�¼��
		int totalCount = 0;
		totalCount = scoreDao.findCountPid(pid);
		pageBean.setTotalCount(totalCount);
		// �����ܵ�ҳ��
		int totalPage = 0;
		if (totalCount % limit == 0) {
			totalPage = totalCount / limit;
		} else {
			totalPage = totalCount / limit + 1;
		}
		pageBean.setTotalPage(totalPage);
		// ÿҳ��ʾ�����ݼ���
		// ��������¼��ʼ
		int begin = (page - 1) * limit;
		List<Student> list = studentDao.findByPageTid(pid, begin, limit);
		pageBean.setList(list);
		return pageBean;
	}
	   public List<PAper> ckpaper(Integer pid) {
			
			return scoreDao.ckpaper(pid);
		}
	 
		
		//���ӳɼ���Ϣʵ��
		public void addStudentSX(Score score, Integer pid) {
			studentDao.addScoreSX(score,pid);	
		}
       

		//����ɾ��ѧ���ɼ���Ϣ
		public void deleteScore(Integer sid) {
			studentDao.deleteScore(sid);
		}
		
		
	}
