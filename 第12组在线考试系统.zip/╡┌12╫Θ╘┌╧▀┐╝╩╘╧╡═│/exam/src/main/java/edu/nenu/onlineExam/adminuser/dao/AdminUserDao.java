package edu.nenu.onlineExam.adminuser.dao;

import java.util.ArrayList;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import edu.nenu.onlineExam.adminuser.entity.AdminUser;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;
import edu.nenu.onlineExam.utils.PageHibernateCallback;

public class AdminUserDao extends HibernateDaoSupport {
	public AdminUser login(AdminUser admin)
	{
	   List<AdminUser> list =(List<AdminUser>) this.getHibernateTemplate().findByExample(admin,0,1);
       if (list != null && list.size()>0)
       {
    	   return list.get(0);
       }
		return null;
	}

	public void uppwd(AdminUser admin, String npw) {
		   List<AdminUser> list =(List<AdminUser>) this.getHibernateTemplate().findByExample(admin,0,1);
	       if (list != null && list.size()>0)
	       {
	    	   AdminUser newAdmin = list.get(0);
	    	   newAdmin.setPassword(npw);
	    	   this.getHibernateTemplate().save(newAdmin);
    	   
	       }
		 
			
	 
	}

	public int findCountTid(Integer tid) {
		String hql = "select count(*) from Student s where s.course.teacherUser.tid= ?";
		List<Long> list = (List<Long>) this.getHibernateTemplate().find(hql, new Object[]{tid});
		if(list != null && list.size()>0){
			return list.get(0).intValue();
		}
		return 0;
	}
		
	public List<Student> findByPageTid(Integer tid, int begin, int limit) {
		//SELECT s.* from teacheruser t, course c, student s where t.tid = c.tid and c.cid = s.cid and t.tid = 200123
		String hql = "select s from Student s join s.course c join b.teacherUser t where t.tid = ? order by s.sid";
		//��ҳʵ��
		List<Student> list = this.getHibernateTemplate().execute(new PageHibernateCallback<Student>(hql, new Object[]{tid}, begin, limit));
		List<Student> liststu = new ArrayList<Student>();
		String hql2 = null;
		for(int i=0; i<list.size();i++){
			Student stu = list.get(i);
			hql2 = "from CoUrse where cid = ?";
			List<CoUrse> listbj = (List<CoUrse>) this.getHibernateTemplate().find(hql2, new Object[] {list.get(i).getCourse().getCid()});
			if(listcourse!=null && listcourse.size()>0){
				stu.setCourse(listcourse.get(0));
			}
			liststu.add(stu);
		}
		return liststu;
	}

	private Object getHibernateTemplate() {
		// TODO �Զ����ɵķ������
		return null;
	}

	public List<CoUrse> ckcourse(Integer tid) {
		String hql = "from CoUrse where tid = ?";
		List<CoUrse> list = (List<CoUrse>) this.getHibernateTemplate().find(hql, tid);
		return list;
		
	}
 
	public Student finBySid(Integer sid) {
		String hql = "from Student where sid = ?";
		List<Student> list = (List<Student>) this.getHibernateTemplate().find(hql, sid);
		if(list!=null && list.size()>0){
			return list.get(0);
		}
		return null;
	}
	public void addStudentSX(Student student, Integer cid,Integer gid) {
		String hql = "from CoUrse where cid = ?";
		List<CoUrse> list = (List<CoUrse>) this.getHibernateTemplate().find(hql, cid);
	    CoUrse course = null;
		if(list!=null && list.size()>0){
			course = list.get(0);
		}
		student.setCourse(course);
		this.getHibernateTemplate().save(student);
	}
public void deleteStudent(Integer sid) {
		
		String hql2 = "from Student where sid = ?";
		List<Student> liststu = (List<Student>) this.getHibernateTemplate().find(hql2, sid);
		this.getHibernateTemplate().delete(liststu.get(0));
	}
public int findCountTid(Integer tid) {
	String hql = "select count(*) from Student s where s.course.teacherUser.tid= ?";
	List<Long> list = (List<Long>) this.getHibernateTemplate().find(hql, new Object[]{tid});
	if(list != null && list.size()>0){
		return list.get(0).intValue();
	}
	return 0;
}
	
public List<TeacherUser> findByPageCid(Integer cid, int begin, int limit) {
	//SELECT t.* from teacheruser t, course c,where t.tid = c.tid  and c.cid = 20
	String hql = "select t from Teacheruser t join t.course c  where c.cid = ? order by t.tid";
	//��ҳʵ��
	List<TeacherUser> list = this.getHibernateTemplate().execute(new PageHibernateCallback<Student>(hql, new Object[]{cid}, begin, limit));
	List<TeacherUser> listtea = new ArrayList<TeacherUser>();
	String hql2 = null;
	for(int i=0; i<list.size();i++){
		TeacherUser tea = list.get(i);
		hql2 = "from CoUrse where cid = ?";
		List<CoUrse> listcourse = (List<CoUrse>) this.getHibernateTemplate().find(hql2, new Object[] {list.get(i).getCourse().getCid()});
		if(listcourse!=null && listcourse.size()>0){
			tea.setCourse(listcourse.get(0));
		}
		listtea.add(tea);
	}
	return listtea;
}


public TeacherUser finByTid(Integer tid) {
	String hql = "from TeacherUser where tid = ?";
	List<TeacherUser> list = (List<TeacherUser>) this.getHibernateTemplate().find(hql, tid);
	if(list!=null && list.size()>0){
		return list.get(0);
	}
	return null;
}
public void addTeacheruserSX(TeacherUser teacheruser, Integer cid) {
	String hql = "from CoUrse where cid = ?";
	List<CoUrse> list = (List<CoUrse>) this.getHibernateTemplate().find(hql, cid);
    CoUrse course = null;
	if(list!=null && list.size()>0){
		course = list.get(0);
	}
	teacheruser.setCourse(course);
	this.getHibernateTemplate().save(teacheruser);
}
public void deleteTeacheruser(Integer tid) {
	
	String hql2 = "from TeacherUser where tid = ?";
	List<TeacherUser> liststu = (List<TeacherUser>) this.getHibernateTemplate().find(hql2, sid);
	this.getHibernateTemplate().delete(liststu.get(0));
}
}
