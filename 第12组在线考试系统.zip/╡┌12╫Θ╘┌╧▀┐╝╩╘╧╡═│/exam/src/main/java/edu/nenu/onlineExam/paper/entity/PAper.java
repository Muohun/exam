package edu.nenu.onlineExam.paper.entity;

import java.util.HashSet;
import java.util.Set;

import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.question.action.QuestionAction;
import edu.nenu.onlineExam.question.entity.Question;
import edu.nenu.onlineExam.score.entity.Score;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.teacheruser.entity.TeacherUser;

public class PAper {


	private Integer pid;
	private String pname;
	private CoUrse course;
	private TeacherUser teacherUser;
	private Set<Score> scores = new HashSet<Score>();
	private Set<Question> quenstions = new HashSet<Question>();
	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public Set<Score> getScores() {
		return scores;
	}

	public void setScores(Set<Score> scores) {
		this.scores  = scores;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public CoUrse getCourse() {
		return course;
	}
	public void setCourse(CoUrse course) {
		this.course = course;
	}

	public Set<Question> getQuenstions() {
		return quenstions;
	}

	public void setQuenstions(Set<Question> quenstions) {
		this.quenstions = quenstions;
	}
	public TeacherUser getTeacherUser() {
		return teacherUser;
	}

	public void setTeacherUser(TeacherUser teacherUser) {
		this.teacherUser = teacherUser;
	}


}
