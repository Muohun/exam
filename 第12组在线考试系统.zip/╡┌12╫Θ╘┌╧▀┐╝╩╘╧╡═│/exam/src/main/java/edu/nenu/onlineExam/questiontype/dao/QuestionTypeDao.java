package edu.nenu.onlineExam.questiontype.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import edu.nenu.onlineExam.bj.entity.BJ;
import edu.nenu.onlineExam.course.entity.CoUrse;
import edu.nenu.onlineExam.grade.entity.GRade;
import edu.nenu.onlineExam.question.entity.Question;
import edu.nenu.onlineExam.questiontype.entity.QuestionType;
import edu.nenu.onlineExam.student.dao.StudentDao;
import edu.nenu.onlineExam.student.entity.Student;
import edu.nenu.onlineExam.utils.PageHibernateCallback;

public class QuestionTypeDao extends HibernateDaoSupport {

	public int findCountTid(Integer tid) {
		String hql = "select count(*) from Question q where q.course.teacherUser.tid= ?";
		List<Long> list = (List<Long>)  this.getHibernateTemplate().find(hql, new Object[]{tid});
		if(list != null && list.size()>0){
			return list.get(0).intValue();
		}
		return 0;
	}
		
	public List< Question> findByPageTid(Integer tid, int begin, int limit) {
		//SELECT s.* from teacheruser t,  question q, course c where t.tid = c.tid and g.gid = s.cid and t.tid = 200123
		String hql = "select q from  Question q join q.course c join c.teacherUser t where t.tid = ? order by q.qid";
		//��ҳʵ��
		List< Question> list = this.getHibernateTemplate().execute(new PageHibernateCallback< Question>(hql, new Object[]{tid}, begin, limit));
		List< Question> listque = new ArrayList< Question>();
		String hql2 = null;
		for(int i=0; i<list.size();i++){
			 Question que = list.get(i);
			hql2 = "from Quenstion where qid = ?";
			List< QuestionType> listquestiontype = (List< QuestionType>) this.getHibernateTemplate().find(hql2, new Object[] {list.get(i).getQuestionType().getQtid()});
			if(listquestiontype!=null && listquestiontype.size()>0){
				que.setQuestionType(listquestiontype.get(0));
			}
			listque.add(que);
		}
		return listque;
	}

	private Object getHibernateTemplate() {
		// TODO �Զ����ɵķ������
		return null;
	}

	public static Question finByzQid(Integer qid) {
		String hql = "from Question where qid = ?";
		List<Question> list = (List<Question>) this.getHibernateTemplate().find(hql, qid);
		if(list!=null && list.size()>0){
			return list.get(0);
		}
		return null;
	}
}

